<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Mplan Matrimonials Website | Profile Page</title>
	 <link rel="icon" type="image/png" href="<?php echo base_url();?>img/icon.jpg" >
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Page Description and Author -->
	<meta name="description" content="<?php echo $descripation;?>">
	<meta name="keywords" content="<?php if(isset($keywords)){echo $keywords;}?>">
	<meta name="author" content="shivamanhar">



        <!-- CSS -->

        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>

        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Oleo+Script:400,700'>

        <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url();?>css/full_page.css">
     
	<link rel="stylesheet" href="<?php echo base_url();?>css/dataurl.css">

        <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.css">
     
	<meta name="google-site-verification" content="SSQBLbJNYGybBIe_qhID49_4ri_oKLn3hi9f7gBuTJ4" />
	<meta name="alexaVerifyID" content="WhBcUlec2wxBZQCImPFKg-Hp4lQ"/>
	
	
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->

        <!--[if lt IE 9]>

            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
            

        <![endif]-->
	<!-- google analysis traking -->
        <script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');		
		  ga('create', 'UA-63183737-1', 'auto');
		  ga('send', 'pageview');		
	</script>

    </head>