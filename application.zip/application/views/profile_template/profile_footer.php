 
        <!-- footer-->
        <footer class="content-info" role="contentinfo">
                <div class="container">
                
                 <div class="row">
                         
                <hr/>
                <div class="sotto-footer">
               
                     
                <div class="icone-social">
              
                </div>
               
                 <p class="copyright" style="color:#C3C100"><a href="<?php echo base_url();?>terms-conditions">Terms & Conditions </a> | <a href="<?php echo base_url();?>privacypolicy">Privacy Policy </a> |  <a href="<?php echo base_url();?>welcome/contact_us">Contact Us</a> - &copy; 2015 mplan.in Matrimonials  </p>
                  
                   
                </div>
                </div>
                 
</footer>
</div>
        
        <!-- footer end -->
        
        <input type="hidden" value="<?php echo base_url();?>" id="url" name="url">
        <!-- Javascript -->
        <script src="<?php echo base_url();?>js/jquery-1.8.2.min.js"></script>
        <script src="<?php echo base_url();?>js/mplan.js"></script>
	<script src="<?php echo base_url();?>js/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>js/scripts.js"></script>

    </body>

</html>
