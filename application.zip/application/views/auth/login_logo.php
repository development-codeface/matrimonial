<div class="header">
            <div class="container">
                <div class="row">
                    <div class="logo span4">
                        <h1><a href="http://mplan.in/">Mplan Register(free)<span class="red">.</span></a> <span style="float:right"> <a class="home" href="http://mplan.in/" > <i class="fa fa-home"></i> </a> </span></h1>
                    </div>             
                </div>
            </div>
        </div>