<!doctype html>
<html lang="en">
<!-- codeface-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" href="<?php echo base_url();?>img/icon.jpg" >
    <meta name="author" content="codeface">
    <meta name="robots" content="index, auth/register/">
    <meta name="googlebot" content="index, auth/register/">
    <meta name="Distribution" content="Global">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Varela+Round" rel="stylesheet">
    <script src="<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/font-awesome.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/selectize.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/user.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/croppie.css" type="text/css">
    <title>Matrimony Site</title>

</head>
