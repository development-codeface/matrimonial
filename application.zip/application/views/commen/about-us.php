<section class="content">
            <section class="block">
                <!--Gallery Carousel-->
                <section>
                    <div class="owl-carousel full-width-carousel">
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz.jpg" alt="" data-hash="1"></div>
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz1.jpg" alt="" data-hash="2"></div>
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz.jpg" alt="" data-hash="4"></div>
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz1.jpg" alt="" data-hash="5"></div>
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz.jpg" alt="" data-hash="6"></div>
                        <div class="item background-image"><img src="<?php echo base_url();?>assets/img/bz1.jpg" alt="" data-hash="3"></div>
                    </div>
                </section>
                <!--end Gallery Carousel-->
                <div class="container">
                    <div class="row flex-column-reverse flex-md-row">
                        <!--============ Listing Detail =============================================================-->
                        <div class="col-md-12">
                            <!--Description-->
                            <section>
                                <h2>About Us</h2>
                                <p style="text-align: justify;">
                                    A warm welcome to pkeralamarry.com, a marriage helpline service. We assure you that we will choose your partner for you. Every life has its own charm in each stage and a married life is noexpectation. Pkeralamarry.com have only one aim‘ to help you to find a better partner for you’. As we know, marriage is an institution which initiates the authentic values of life. In our country like India, marriage is usually arranged by the family or relatives of the bride or groom within a known circles. But today's generation doesn't narrowed this choice and hence marriage , search Profileswebsites plays a vital roles.<br><br>
Our service is a trusted one and we provide matrimony service solely based on community. When you register on pkeralamarry.com, based  on your community your profile you will be assigned to the relevant community. In our site, where you can search and contact profiles from your community. We provides the widest choice of profiles that matches your criteria and expectations. Matches are made based on both traditional and scientific  to find a  companion for life that perfectly blend with you and your ideologies any, ofcourse your family too. We assure that Pkeralamarry.com is 100% privacy guaranteed, safe and  secure.

                                </p>
                            </section>
                            <!--end Description-->
                            <!--Details-->
                           
                            <!--end Details-->
                            <!--Location-->
                          
                            <!--Features-->
                          
                            <!--end Features-->

                            <hr>

                
                        </div>
                        <!--============ End Listing Detail =========================================================-->
                        <!--============ Sidebar ====================================================================-->
                       
                        <!--============ End Sidebar ================================================================-->
                    </div>
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->

            <!--============ Features Steps =========================================================================-->
            <section class="block has-dark-background">
                <div class="container">
                    <div class="block">
                        <h2>Join With Us Is Easy</h2>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo base_url();?>assets/icons/feature-user.png" alt="">
                                        <span>1</span>
                                    </figure>
                                    <h3>Create account with Pkeralamarry.com</h3>
                                    
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo base_url();?>assets/icons/feature-upload.png" alt="">
                                        <span>2</span>
                                    </figure>
                                    <h3>Submit your profile</h3>
                                   
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo base_url();?>assets/icons/feature-like.png" alt="">
                                        <span>3</span>
                                    </figure>
                                    <h3>Search genuine profiles</h3>
                                    
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo base_url();?>assets/icons/feature-wallet.png" alt="">
                                        <span>4</span>
                                    </figure>
                                    <h3>Find your companion</h3>
                                    
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                        </div>
                        <!--end row-->
                    </div>
                    <!--end block-->
                </div>
                <!--end container-->
                <div class="background" data-background-color="#2b2b2b"></div>
                <!--end background-->
            </section>
            <!--end block-->
        <!--*********************************************************************************************************-->
        <!--************ FOOTER *************************************************************************************-->
        <!--*********************************************************************************************************-->
        