    <!-- footer-->
        <footer class="content-info" role="contentinfo">
                <div class="container">
                
                 <div class="row">
                         
                <hr/>
                <div class="sotto-footer">
               
                     
                <div class="icone-social">
              
                </div>
               
                 <p class="copyright" style="color:#C3C100"><a href="<?php echo base_url();?>terms-conditions">Terms & Conditions </a> | <a href="<?php echo base_url();?>privacypolicy">Privacy Policy </a> | <a href="<?php echo base_url();?>welcome/contact_us">Contact Us</a> - &copy; matrimony </p>
                  
                   
                </div>
                </div>
                 
                <input type="hidden" value="<?php echo base_url();?>" id="url" name="url">
                </div>
        </footer>
  </div>
        <!-- footer end -->
        <div class="modal fade" id="cropImagePop" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                          <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title" id="myModalLabel">
                                Edit Photo</h4>
                            </div>
                            <div class="modal-body">
                            <div id="upload-demo" class="center-block"></div>
                      </div>
                             <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" id="cropImageBtn" class="btn btn-primary">Crop</button>
      </div>
                            </div>
                          </div>
                        </div>
    <!--end page-->
    
  <script src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/popper.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/croppie.js"></script>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyBEDfNcQRmKQEyulDN8nGWjLYPm8s4YB58&amp;libraries=places"></script>
	<script src="<?php echo base_url();?>assets/js/selectize.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/masonry.pkgd.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/icheck.min.js"></script>
	
	<script src="../../../cdn.jsdelivr.net/npm/jquery-validation%401.17.0/dist/jquery.validate.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery-validate.bootstrap-tooltip.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jQuery.MultiFile.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/custom.js"></script>
  <script src="<?php echo base_url();?>assets/js/choosen.js"></script>


    </body>
</html>