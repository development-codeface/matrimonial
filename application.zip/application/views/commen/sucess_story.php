 <!--end hero-->

        <!--*********************************************************************************************************-->
        <!--************ CONTENT ************************************************************************************-->
        <!--*********************************************************************************************************-->
        <section class="content">

            <section class="block">

                <div class="container"> <h1 style="padding-bottom: 20px;">Success Stories</h1>
                    <div class="row">
                        <div class="col-md-6">

                            <article class="blog-post clearfix">
                                <a href="blog-post.html">
                                    <img src="<?php echo base_url();?>assets/img/bz.jpg" alt="">
                                </a>
                                <div class="article-title">
                                    <h2><a href="#">Keerthi and Anoop </a></h2>
                                   
                                </div>
                                
                                <div class="blog-post-content">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit
                                        amet fermentum sem. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                                        per inceptos himenaeos. Vestibulum tincidunt, sapien sagittis sollicitudin dapibus,
                                        risus mi euismod elit
                                    </p>
                                  <!--   <a href="blog-post.html" class="btn btn-primary btn-framed detail">Read more</a> -->
                                </div>
                            </article>

                            <!--end Articles-->

                           
                            <!--end page-pagination-->
                        </div>
                        <!--end col-md-8-->

                        <div class="col-md-6">

                            <article class="blog-post clearfix">
                                <a href="blog-post.html">
                                    <img src="<?php echo base_url();?>assets/img/bz1.jpg" alt="">
                                </a>
                                <div class="article-title">
                                    <h2><a href="#">Manu and Aneena</a></h2>
                                    
                                </div>
                                
                                <div class="blog-post-content">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit
                                        amet fermentum sem. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                                        per inceptos himenaeos. Vestibulum tincidunt, sapien sagittis sollicitudin dapibus,
                                        risus mi euismod elit
                                    </p>
                                    <!-- <a href="blog-post.html" class="btn btn-primary btn-framed detail">Read more</a> -->
                                </div>
                            </article>

                            

                          
                            <!--end Articles-->

                           
                        </div> 

                        <!--end col-md-8-->
                    </div> <div class="page-pagination">
                                <nav aria-label="Pagination">
                                    <ul class="pagination">
                                        <li class="page-item">
                                            <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">
                                            <i class="fa fa-chevron-left"></i>
                                        </span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <li class="page-item active">
                                            <a class="page-link" href="#">1</a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="#">2</a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="#">3</a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">
                                            <i class="fa fa-chevron-right"></i>
                                        </span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <!--end page-pagination-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->

        <!--*********************************************************************************************************-->
        <!--************ FOOTER *************************************************************************************-->
        <!--*********************************************************************************************************-->
         