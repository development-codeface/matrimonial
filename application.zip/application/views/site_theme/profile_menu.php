<section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <!--============ Side Bar ===============================================================-->
                            <aside class="sidebar">  
							<?php 
                                $this->load->view('site_theme/muser_navigation');   
                                //$this->load->view('site_theme/site_search_box');
                            ?>   
                            </aside>
                            <!--============ End Side Bar ===========================================================-->
                        </div>