<section>
                                    <ul class="sidebar-list list-unstyled">
                                        <li>
                                            <a href="<?php echo base_url();?>">All Users </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>admin/inactiveuser">Activate Request</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>admin/profileupdate">Profile Update Request </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>admin/newphotoupdate">Photo update Request</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>admin/blockeduser">Blocked user</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>admin/paymentrequest">Payment request</a>
                                        </li>
                                        
                                        
                                       
                                        
                                        <!--<li>
                                            <a href="short_listed.html">Short listed<span>3</span></a>
                                        </li>
                                        <li>
                                            <a href="who_shortlisted_me.html">Who Shortlisted Me 
<span>3</span></a>
                                        </li>
                                        <li>
                                            <a href="profiles_visited.html">Profiles Visited <span>11</span></a>
                                        </li>
                                        <li>
                                            <a href="my_profile_views.html">My Profile Views <span>17</span></a>
                                        </li> 
                                        <li><a href="<?php echo base_url();?>account_setting">Account Setting</a></li> -->
                                    </ul>
                                </section>