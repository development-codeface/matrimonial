<section>
                                    <ul class="sidebar-list list-unstyled">
                                        <li>
                                            <a href="<?php echo base_url();?>">Home </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>update_profile/index/<?php echo $this->tank_auth->get_user_id(); ?>">Edit Profile </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>muser/index/<?php echo $this->tank_auth->get_user_id(); ?>">My Profile </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>partner_profile/partner_basic_info/<?php echo $this->tank_auth->get_user_id(); ?>">Edit Partners Preference </a>
                                        </li>
                                       <li>
                                            <a href="<?php echo base_url();?>muser/photo/">Manage Photos </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>inbox/">Messages</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url();?>muser/shortlistprofile">Your Shorlist profiles</a>
                                        </li>
                                        <li>    
                                            <a href="<?php echo base_url();?>muser/interestedprofile">Interest sent</a>
                                        </li>
                                        <!--<li>
                                            <a href="short_listed.html">Short listed<span>3</span></a>
                                        </li>
                                        <li>
                                            <a href="who_shortlisted_me.html">Who Shortlisted Me 
<span>3</span></a>
                                        </li>
                                        <li>
                                            <a href="profiles_visited.html">Profiles Visited <span>11</span></a>
                                        </li>
                                        <li>
                                            <a href="my_profile_views.html">My Profile Views <span>17</span></a>
                                        </li> -->
                                        <li><a href="<?php echo base_url();?>account_setting">Account Setting</a></li>
                                    </ul>
                                </section>