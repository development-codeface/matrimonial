function menu_select(data)
{
    $('a').removeClass('active');
    $(data).addClass('active');
}
